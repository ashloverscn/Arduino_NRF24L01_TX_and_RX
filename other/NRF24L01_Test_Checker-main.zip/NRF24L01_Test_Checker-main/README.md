# NRF24L01_Test_Checker
This files are about to test NRF24L01 module good or bad and to see if it works or not. This includes OLD LIBRARY but very compatible to all NRF24L01 types.
<p>If you still find "delay(1000)" code inside the sketch, then REMOVE it to make it work 100%</p>
<p>Credit for: https://howtomechatronics.com/ (thanks, pal)</p>
